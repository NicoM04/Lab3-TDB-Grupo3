create function st_lineinterpolatepoints(text, double precision) returns geometry
    immutable
    parallel safe
    language sql
as
$$ SELECT public.ST_LineInterpolatePoints($1::public.geometry, $2);  $$;

alter function st_lineinterpolatepoints(text, double precision) owner to postgres;

