create function dropgeometrytable(table_name character varying) returns text
    strict
    language sql
as
$$ SELECT public.DropGeometryTable('','',$1) $$;

alter function dropgeometrytable(varchar) owner to postgres;

