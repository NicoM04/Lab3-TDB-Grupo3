create function registrar_problema_critico() returns trigger
    language plpgsql
as
$$
DECLARE
    v_descripcion TEXT;
BEGIN
    -- Problema: Pedido cancelado
    IF NEW.estado = 'Cancelado' AND (OLD.estado IS DISTINCT FROM 'Cancelado') THEN
        v_descripcion := 'El pedido ha sido cancelado por un motivo no especificado.';

        INSERT INTO Notificacion (
            id_pedido, fecha_creacion, mensaje, tipo, leida, descripcion
        ) VALUES (
            NEW.id_pedido,
            CURRENT_DATE,
            FORMAT('El pedido #%s ha sido cancelado.', NEW.id_pedido),
            'Problema critico',
            FALSE,
            v_descripcion
        );
    END IF;

    -- Problema: Pedido confirmado sin repartidor
    IF NEW.estado = 'Confirmado' AND (OLD.estado IS DISTINCT FROM 'Confirmado') THEN
        IF NEW.id_repartidor IS NULL THEN
            v_descripcion := 'El pedido fue confirmado pero no tiene repartidor asignado.';

            INSERT INTO Notificacion (
                id_pedido, fecha_creacion, mensaje, tipo, leida, descripcion
            ) VALUES (
                NEW.id_pedido,
                CURRENT_DATE,
                FORMAT('Pedido #%s confirmado sin repartidor asignado.', NEW.id_pedido),
                'Problema critico',
                FALSE,
                v_descripcion
            );
        END IF;
    END IF;

    RETURN NEW;
END;
$$;

alter function registrar_problema_critico() owner to postgres;

