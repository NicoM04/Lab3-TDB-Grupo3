create function insertar_calificacion_automatica() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Verificar que el estado es "Entregado"
    IF NEW.estado = 'Entregado' AND (OLD.estado IS DISTINCT FROM 'Entregado') THEN
        RAISE NOTICE 'Estado es "Entregado".';

        -- Verificar si han pasado 48 horas desde la fecha de pedido
        IF CURRENT_DATE - NEW.fecha_pedido >= 2 THEN
            RAISE NOTICE 'Han pasado mas de 48 horas desde el pedido.';

            -- Verificar si no existe una calificación para este repartidor y fecha de entrega
            IF NOT EXISTS (
                SELECT 1 FROM Calificaciones
                WHERE id_repartidor = NEW.id_repartidor
                AND fecha_calificacion = NEW.fecha_entrega
            ) THEN
                -- Insertar la calificación
                INSERT INTO Calificaciones (
                    id_repartidor, puntuacion, comentario, fecha_calificacion
                ) VALUES (
                    NEW.id_repartidor, 3,
                    'Calificacion automatica por no responder en 48 horas',
                    NEW.fecha_entrega
                );
                RAISE NOTICE 'Calificacion insertada.';
            ELSE
                RAISE NOTICE 'Ya existia una calificacion para ese repartidor y fecha.';
            END IF;
        ELSE
            RAISE NOTICE 'Aun no han pasado 48 horas desde el pedido.';
        END IF;
    ELSE
        RAISE NOTICE 'Estado no es "Entregado" o no ha cambiado.';
    END IF;

    RETURN NEW;
END;
$$;

alter function insertar_calificacion_automatica() owner to postgres;

